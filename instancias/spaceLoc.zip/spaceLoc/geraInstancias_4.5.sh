./LocalizacaoRSSF -gi -pa 4.5_02-0 -li 0 -ls 1 -nt 3969 -na 50 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_02-1 -li 0 -ls 1 -nt 3969 -na 50 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_02-2 -li 0 -ls 1 -nt 3969 -na 50 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_02-3 -li 0 -ls 1 -nt 3969 -na 50 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_02-4 -li 0 -ls 1 -nt 3969 -na 50 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_02-5 -li 0 -ls 1 -nt 3969 -na 50 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_02-6 -li 0 -ls 1 -nt 3969 -na 50 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_02-7 -li 0 -ls 1 -nt 3969 -na 50 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_02-8 -li 0 -ls 1 -nt 3969 -na 50 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_02-9 -li 0 -ls 1 -nt 3969 -na 50 -ar 0.0334 -fr 0

./LocalizacaoRSSF -gi -pa 4.5_05-0 -li 0 -ls 1 -nt 3969 -na 200 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_05-1 -li 0 -ls 1 -nt 3969 -na 200 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_05-2 -li 0 -ls 1 -nt 3969 -na 200 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_05-3 -li 0 -ls 1 -nt 3969 -na 200 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_05-4 -li 0 -ls 1 -nt 3969 -na 200 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_05-5 -li 0 -ls 1 -nt 3969 -na 200 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_05-6 -li 0 -ls 1 -nt 3969 -na 200 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_05-7 -li 0 -ls 1 -nt 3969 -na 200 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_05-8 -li 0 -ls 1 -nt 3969 -na 200 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_05-9 -li 0 -ls 1 -nt 3969 -na 200 -ar 0.0334 -fr 0

./LocalizacaoRSSF -gi -pa 4.5_09-0 -li 0 -ls 1 -nt 3969 -na 400 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_09-1 -li 0 -ls 1 -nt 3969 -na 400 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_09-2 -li 0 -ls 1 -nt 3969 -na 400 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_09-3 -li 0 -ls 1 -nt 3969 -na 400 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_09-4 -li 0 -ls 1 -nt 3969 -na 400 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_09-5 -li 0 -ls 1 -nt 3969 -na 400 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_09-6 -li 0 -ls 1 -nt 3969 -na 400 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_09-7 -li 0 -ls 1 -nt 3969 -na 400 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_09-8 -li 0 -ls 1 -nt 3969 -na 400 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.5_09-9 -li 0 -ls 1 -nt 3969 -na 400 -ar 0.0334 -fr 0


