./LocalizacaoRSSF -gi -pa 4.6_01-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.01
./LocalizacaoRSSF -gi -pa 4.6_01-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.01
./LocalizacaoRSSF -gi -pa 4.6_01-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.01
./LocalizacaoRSSF -gi -pa 4.6_01-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.01
./LocalizacaoRSSF -gi -pa 4.6_01-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.01
./LocalizacaoRSSF -gi -pa 4.6_01-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.01
./LocalizacaoRSSF -gi -pa 4.6_01-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.01
./LocalizacaoRSSF -gi -pa 4.6_01-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.01
./LocalizacaoRSSF -gi -pa 4.6_01-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.01
./LocalizacaoRSSF -gi -pa 4.6_01-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.01

./LocalizacaoRSSF -gi -pa 4.6_03-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.1
./LocalizacaoRSSF -gi -pa 4.6_03-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.1
./LocalizacaoRSSF -gi -pa 4.6_03-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.1
./LocalizacaoRSSF -gi -pa 4.6_03-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.1
./LocalizacaoRSSF -gi -pa 4.6_03-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.1
./LocalizacaoRSSF -gi -pa 4.6_03-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.1
./LocalizacaoRSSF -gi -pa 4.6_03-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.1
./LocalizacaoRSSF -gi -pa 4.6_03-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.1
./LocalizacaoRSSF -gi -pa 4.6_03-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.1
./LocalizacaoRSSF -gi -pa 4.6_03-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.1

./LocalizacaoRSSF -gi -pa 4.6_07-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.5
./LocalizacaoRSSF -gi -pa 4.6_07-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.5
./LocalizacaoRSSF -gi -pa 4.6_07-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.5
./LocalizacaoRSSF -gi -pa 4.6_07-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.5
./LocalizacaoRSSF -gi -pa 4.6_07-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.5
./LocalizacaoRSSF -gi -pa 4.6_07-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.5
./LocalizacaoRSSF -gi -pa 4.6_07-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.5
./LocalizacaoRSSF -gi -pa 4.6_07-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.5
./LocalizacaoRSSF -gi -pa 4.6_07-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.5
./LocalizacaoRSSF -gi -pa 4.6_07-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0.5


