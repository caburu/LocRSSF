./LocalizacaoRSSF -gi -pa 4.4_01-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_01-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_01-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_01-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_01-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_01-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_01-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_01-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_01-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_01-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0

./LocalizacaoRSSF -gi -pa 4.4_09-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_09-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_09-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_09-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_09-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_09-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_09-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_09-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_09-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_09-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0

./LocalizacaoRSSF -gi -pa 4.4_16-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_16-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_16-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_16-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_16-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_16-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_16-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_16-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_16-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0
./LocalizacaoRSSF -gi -pa 4.4_16-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0


