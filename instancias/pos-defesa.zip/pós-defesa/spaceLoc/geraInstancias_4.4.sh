echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_01-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_02-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0306 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_03-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0308 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_04-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0310 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_05-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0312 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_06-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0314 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_07-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0316 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_08-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0318 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_09-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_10-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0322 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_11-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0324 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_12-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0326 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_13-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0328 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_14-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0330 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_15-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0332 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_16-0 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0

echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_01-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_02-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0306 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_03-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0308 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_04-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0310 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_05-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0312 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_06-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0314 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_07-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0316 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_08-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0318 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_09-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_10-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0322 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_11-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0324 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_12-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0326 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_13-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0328 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_14-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0330 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_15-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0332 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_16-1 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0

echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_01-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_02-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0306 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_03-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0308 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_04-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0310 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_05-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0312 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_06-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0314 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_07-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0316 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_08-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0318 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_09-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_10-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0322 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_11-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0324 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_12-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0326 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_13-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0328 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_14-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0330 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_15-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0332 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_16-2 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0

echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_01-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_02-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0306 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_03-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0308 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_04-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0310 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_05-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0312 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_06-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0314 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_07-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0316 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_08-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0318 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_09-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_10-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0322 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_11-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0324 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_12-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0326 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_13-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0328 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_14-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0330 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_15-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0332 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_16-3 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0

echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_01-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_02-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0306 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_03-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0308 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_04-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0310 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_05-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0312 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_06-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0314 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_07-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0316 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_08-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0318 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_09-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_10-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0322 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_11-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0324 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_12-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0326 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_13-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0328 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_14-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0330 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_15-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0332 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_16-4 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0

echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_01-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_02-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0306 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_03-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0308 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_04-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0310 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_05-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0312 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_06-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0314 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_07-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0316 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_08-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0318 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_09-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_10-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0322 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_11-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0324 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_12-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0326 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_13-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0328 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_14-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0330 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_15-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0332 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_16-5 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0

echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_01-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_02-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0306 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_03-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0308 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_04-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0310 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_05-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0312 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_06-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0314 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_07-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0316 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_08-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0318 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_09-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_10-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0322 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_11-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0324 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_12-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0326 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_13-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0328 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_14-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0330 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_15-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0332 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_16-6 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0

echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_01-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_02-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0306 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_03-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0308 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_04-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0310 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_05-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0312 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_06-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0314 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_07-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0316 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_08-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0318 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_09-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_10-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0322 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_11-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0324 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_12-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0326 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_13-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0328 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_14-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0330 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_15-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0332 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_16-7 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0

echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_01-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_02-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0306 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_03-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0308 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_04-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0310 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_05-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0312 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_06-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0314 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_07-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0316 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_08-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0318 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_09-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_10-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0322 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_11-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0324 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_12-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0326 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_13-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0328 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_14-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0330 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_15-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0332 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_16-8 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0

echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_01-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0304 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_02-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0306 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_03-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0308 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_04-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0310 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_05-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0312 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_06-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0314 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_07-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0316 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_08-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0318 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_09-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0320 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_10-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0322 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_11-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0324 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_12-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0326 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_13-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0328 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_14-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0330 -fr 0
 ../../src/./LocalizacaoRSSF -gi -pa 4.4_15-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0332 -fr 0
echo ../../src/./LocalizacaoRSSF -gi -pa 4.4_16-9 -li 0 -ls 1 -nt 3969 -na 63 -ar 0.0334 -fr 0


